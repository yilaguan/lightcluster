"""User interfaces of igraph"""

